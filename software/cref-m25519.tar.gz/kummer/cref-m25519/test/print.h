#ifndef PRINT_H
#define PRINT_H

#include "../fe25519.h"
#include <stdio.h>

void fe25519_print(const fe25519 *x);

#endif
