#ifndef HASH_H
#define HASH_H

void hash( unsigned char *out, const unsigned char *in, unsigned int inlen );

#endif
