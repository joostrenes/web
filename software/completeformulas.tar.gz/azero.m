clear;

function ADD(X1,Y1,Z1,X2,Y2,Z2,b3)
    t0 := X1*X2;    t1 := Y1*Y2;    t2 := Z1*Z2;
    t3 := X1+Y1;    t4 := X2+Y2;    t3 := t3*t4;
    t4 := t0+t1;    t3 := t3-t4;    t4 := Y1+Z1;
    X3 := Y2+Z2;    t4 := t4*X3;    X3 := t1+t2;
    t4 := t4-X3;    X3 := X1+Z1;    Y3 := X2+Z2;
    X3 := X3*Y3;    Y3 := t0+t2;    Y3 := X3-Y3;
    X3 := t0+t0;    t0 := X3+t0;    t2 := b3*t2;
    Z3 := t1+t2;    t1 := t1-t2;    Y3 := b3*Y3;
    X3 := t4*Y3;    t2 := t3*t1;    X3 := t2-X3;
    Y3 := Y3*t0;    t1 := t1*Z3;    Y3 := t1+Y3;
    t0 := t0*t3;    Z3 := Z3*t4;    Z3 := Z3+t0;
    return X3,Y3,Z3;
end function;

function mADD(X1,Y1,Z1,X2,Y2,b3)
    t0 := X1*X2;    t1 := Y1*Y2;    t3 := X2+Y2;
    t4 := X1+Y1;    t3 := t3*t4;    t4 := t0+t1;
    t3 := t3-t4;    t4 := Y2*Z1;    t4 := t4+Y1;
    Y3 := X2*Z1;    Y3 := Y3+X1;    X3 := t0+t0;
    t0 := X3+t0;    t2 := b3*Z1;    Z3 := t1+t2;
    t1 := t1-t2;    Y3 := b3*Y3;    X3 := t4*Y3;
    t2 := t3*t1;    X3 := t2-X3;    Y3 := Y3*t0;
    t1 := t1*Z3;    Y3 := t1+Y3;    t0 := t0*t3;
    Z3 := Z3*t4;    Z3 := Z3+t0;
    return X3,Y3,Z3;
end function;

function DBL(X,Y,Z,b3)
    t0 := Y^2;      Z3 := t0+t0;    Z3 := Z3+Z3;
    Z3 := Z3+Z3;    t1 := Y*Z;      t2 := Z^2;
    t2 := b3*t2;    X3 := t2*Z3;    Y3 := t0+t2;
    Z3 := t1*Z3;    t1 := t2+t2;    t2 := t1+t2;
    t0 := t0-t2;    Y3 := t0*Y3;    Y3 := X3+Y3;
    t1 := X*Y;      X3 := t0*t1;    X3 := X3+X3;
return X3,Y3,Z3;
end function;

while true do
    repeat 
        repeat 
            repeat q := RandomPrime(8); until q gt 3; 
            Fq := GF(q);
            a := Fq!0; b := Random(Fq); 
        until not (4*a^3+27*b^2 eq 0);
        E := EllipticCurve([Fq|a,b]); 
        b3 := 3*b; 
    until IsOdd(#E);
    for P in Set(E) do
        // ADD
        for Q in Set(E) do
            repeat
                Z1 := Random(Fq); Z2 := Random(Fq);
            until Z1*Z2 ne 0;
            X1 := P[1]*Z1; Y1 := P[2]*Z1; Z1 := P[3]*Z1;
            X2 := Q[1]*Z2; Y2 := Q[2]*Z2; Z2 := Q[3]*Z2;
            X3,Y3,Z3 := ADD(X1,Y1,Z1,X2,Y2,Z2,b3);
            assert E![X3,Y3,Z3] eq P+Q;
        end for;
        // mADD
        for Q in Set(E) do
            if Q[3] ne 0 then // Avoid Q = 0
                assert Q[3] eq 1;
                repeat
                    Z1 := Random(Fq);
                until Z1 ne 0;
                X1 := P[1]*Z1; Y1 := P[2]*Z1; Z1 := P[3]*Z1;
                X3,Y3,Z3 := mADD(X1,Y1,Z1,Q[1],Q[2],b3);
                assert E![X3,Y3,Z3] eq P+Q;
            end if;
        end for;
        // DBL
        repeat Z1 := Random(Fq); until Z1 ne 0;
        X := P[1]*Z1; Y := P[2]*Z1; Z := P[3]*Z1;
        X3,Y3,Z3 := DBL(X,Y,Z,b3);
        assert E![X3,Y3,Z3] eq 2*P;
    end for;
    "ADD / mADD / DBL Complete", q, a, b;
end while;
