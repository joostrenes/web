clear;

function ADD_two(X1,Y1,Z1,X2,Y2,Z2,a,b3)
    t0 := X1+Y1;    t1 := X2+Y2;                    //  1
    t2 := Y1+Z1;    t3 := Y2+Z2;                    //  2
    t0 := t0*t1;    t1 := t2*t3;                    //  3
    t4 := X1*X2;    t6 := Z1*Z2;                    //  4
    t2 := X1+Z1;    t3 := X2+Z2;                    //  5
    t0 := t0-t4;    t1 := t1-t6;                    //  6
    t5 := Y1*Y2;    t2 := t2*t3;                    //  7
    t7 := a*t6;     t8 := b3*t6;                    //  8
    t9 := t4-t7;    t10 := t4+t4;                   //  9
    t11 := t4+t7;   t2 := t2-t4;                    // 10
    t0 := t0-t5;    t1 := t1-t5;                    // 11
    t2 := t2-t6;    t10 := t10+t11;                 // 12
    t9 := a*t9;     t11 := b3*t2;                   // 13
    t2 := a*t2;                                     // 14
    t9 := t9+t11;   t8 := t2+t8;                    // 15
    t6 := t5-t8;    t5 := t5+t8;                    // 16
    t3 := t1*t9;    t9 := t9*t10;                   // 17
    t10 := t0*t10;  t0 := t0*t6;                    // 18
    t6 := t5*t6;    t1 := t1*t5;                    // 19
    X3 := t0-t3;    Y3 := t6+t9;                    // 20
    Z3 := t1+t10;                                   // 21
    return X3,Y3,Z3;
end function;

function ADD_three(X1,Y1,Z1,X2,Y2,Z2,a,b3);
    t0 := X1*X2;    t1 := Y1*Y2;    t2 := Z1*Z2;    //  1
    t3 := X1+Y1;    t4 := X2+Y2;    t5 := Y1+Z1;    //  2
    t6 := Y2+Z2;    t7 := X1+Z1;    t8 := X2+Z2;    //  3
    t9 := t3*t4;    t10 := t5*t6;   t11 := t7*t8;   //  4
    t3 := t0+t1;    t4 := t1+t2;    t5 := t0+t2;    //  5
    t6 := b3*t2;    t8 := a*t2;                     //  6
    t2 := t9-t3;    t9 := t0+t0;    t3 := t10-t4;   //  7
    t10 := t9+t0;   t4 := t11-t5;   t7 := t0-t8;    //  8
    t0 := a*t4;     t5 := b3*t4;    t9 := a*t7;     //  9
    t4 := t0+t6;    t7 := t5+t9;    t0 := t8+t10;   // 10
    t5 := t1-t4;    t6 := t1+t4;                    // 11
    t1 := t5*t6;    t4 := t0*t7;    t8 := t3*t7;    // 12
    t9 := t2*t5;    t10 := t3*t6;   t11 := t0*t2;   // 13
    X3 := t9-t8;    Y3 := t1+t4;    Z3 := t10+t11;  // 14
    return X3,Y3,Z3;
end function;

function ADD_four(X1,Y1,Z1 ,X2 ,Y2 ,Z2,a,b3);
    t0 := X1+Y1;    t1 := X2+Y2;
    t2 := Y1+Z1;    t3 := Y2+Z2;                    //  1
    t0 := t0*t1;    t1 := t2*t3;
    t4 := X1*X2;    t6 := Z1*Z2;                    //  2
    t2 := X1+Z1;    t3 := X2+Z2;
    t0 := t0-t4;    t1 := t1-t6;                    //  3
    t5 := Y1*Y2;    t2 := t2*t3;
    t7 := a*t6;;    t8 := b3*t6;                    //  4
    t9 := t4-t7;    t10 := t4+t4;
    t11 := t4+t7;   t2 := t2-t4;                    //  5
    t0 := t0-t5;    t1 := t1-t5;
    t2 := t2-t6;    t10 := t10+t11;                 //  6
    t9 := a*t9;     t11 := b3*t2;   t2 := a*t2;     //  7
    t9 := t9+t11;                                   //  8
    t3 := t1*t9;    t9 := t9*t10;
    t10 := t0*t10;  t8 := t2+t8;                    //  9
    t6 := t5-t8;    t5 := t5+t8;                    // 10
    t0 := t0*t6;    t6 := t5*t6;    t1 := t1*t5;    // 11
    X3 := t0-t3;    Y3 := t6+t9;    Z3 := t1+t10;   // 12
    return X3,Y3,Z3;
end function;

function ADD_five(X1,Y1,Z1,X2,Y2,Z2,a,b3);
    t5 := X1+Y1;    t6 := X2+Y2;    t7 := X1+Z1;
    t8 := X2+Z2;    t9 := Y1+Z1;                    //  1
    t0 := X1*X2;    t1 := Y1*Y2;    t2 := Z1*Z2;
    t3 := t5*t6;    t4 := t7*t8;                    //  2
    t10 := Y2+Z2;   t3 := t3-t0;    t4 := t4-t0;
    t11 := t0+t0;                                   //  3
    t3 := t3-t1;    t4 := t4-t2;    t11 := t11+t0;  //  4
    t5 := t9*t10;   t6 := b3*t2;    t7 := a*t2;
    t8 := a*t4;     t9 := b3*t4;                    //  5
    t5 := t5-t1;    t11 := t11+t7;  t4 := t0-t7;
    t10 := t6+t8;                                   //  6
    t0 := a*t4;     t6 := t3*t11;                   //  7
    t0 := t0+t9;    t7 := t1-t10;   t10 := t1+t10;
    t5 := t5-t2;                                    //  8
    t1 := t3*t7;    t2 := t5*t0;    t4 := t10*t7;
    t8 := t11*t0;   t9 := t5*t10;                   //  9
    X3 := t1-t2;    Y3 := t4+t8;    Z3 := t9+t6;    // 10
    return X3,Y3,Z3;
end function;

function ADD_six(X1,Y1,Z1,X2,Y2,Z2,a,b3)
    t0 := X1+Y1;    t1 := X2+Y2;    t2 := Y1+Z1;
    t3 := Y2+Z2;    t4 := X1+Z1;    t5 := X2+Z2;    //  1
    t0 := t0*t1;    t1 := t2*t3;    t2 := t4*t5;
    t3 := X1*X2;    t4 := Y1*Y2;    t5 := Z1*Z2;    //  2
    t0 := t0-t3;    t1 := t1-t4;    t2 := t2-t5;    //  3
    t0 := t0-t4;    t1 := t1-t5;    t2 := t2-t3;    //  4
    t6 := b3*t5;    t7 := a*t5;     t8 := a*t2;
    t9 := b3*t2;    t10 := a*t3;    t11 := a^2*t5;  //  5
    t6 := t6+t8;    t7 := t3+t7;    t8 := t3+t3;
    t9 := t9+t10;                                   //  6
    t9 := t9-t11;   t8 := t8+t7;    t7 := t4-t6;
    t6 := t4+t6;                                    //  7
    t3 := t0*t7;    t4 := t0*t8;    t5 := t1*t9;
    t8 := t8*t9;    t7 := t6*t7;    t6 := t1*t6;    //  8
    X3 := t3-t5;    Y3 := t7+t8;    Z3 := t6+t4;    //  9
    return X3,Y3,Z3;
end function;

while true do
    repeat q := RandomPrime(8); until q gt 3; Fq:=GF(q);
    repeat 
        repeat 
            a := Random(Fq); b := Random(Fq); 
        until not (4*a^3+27*b^2 eq 0);
        E := EllipticCurve([Fq|a,b]); 
        b3 := 3*b; 
    until IsOdd(#E);
    for P in Set(E) do
        // ADD
        for Q in Set(E) do
            repeat
                Z1 := Random(Fq); Z2 := Random(Fq);
            until Z1*Z2 ne 0;
            X1 := P[1]*Z1; Y1 := P[2]*Z1; Z1 := P[3]*Z1;
            X2 := Q[1]*Z2; Y2 := Q[2]*Z2; Z2 := Q[3]*Z2;
            X3,Y3,Z3 := ADD_two(X1,Y1,Z1,X2,Y2,Z2,a,b3);
            assert E![X3,Y3,Z3] eq P+Q;
            X3,Y3,Z3 := ADD_three(X1,Y1,Z1,X2,Y2,Z2,a,b3);
            assert E![X3,Y3,Z3] eq P+Q;
            X3,Y3,Z3 := ADD_four(X1,Y1,Z1,X2,Y2,Z2,a,b3);
            assert E![X3,Y3,Z3] eq P+Q;
            X3,Y3,Z3 := ADD_five(X1,Y1,Z1,X2,Y2,Z2,a,b3);
            assert E![X3,Y3,Z3] eq P+Q;
            X3,Y3,Z3 := ADD_six(X1,Y1,Z1,X2,Y2,Z2,a,b3);
            assert E![X3,Y3,Z3] eq P+Q;
        end for;
    end for;
    "ADD", q, a, b;
end while;
