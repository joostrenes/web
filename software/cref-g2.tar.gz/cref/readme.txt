/*
 * Author: Joost Renes
 * Version: 2017-05-23
 * Public Domain
 */

To run:

make
./test/test
