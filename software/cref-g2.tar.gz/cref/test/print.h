#ifndef PRINT_H
#define PRINT_H

#include "../fe1271.h"
#include <stdio.h>

void fe1271_print(const unsigned char *x, const int len);

#endif
