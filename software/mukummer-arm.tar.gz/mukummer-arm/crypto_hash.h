int crypto_hash0( unsigned char *out, const unsigned char *in, unsigned long long inlen );
